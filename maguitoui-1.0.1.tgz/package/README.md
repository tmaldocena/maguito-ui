# MaguitoUI ✨

Librería de componentes React con estética Neo-Brutalista y toques orgánicos ("Bubbly") diseñada para magos creativos en **Maguito Studio**.

## Instalación

```bash
npm install maguitoui
```

## Configuración Técnica

### 1. Tailwind Config
Usa nuestro preset para tener acceso instantáneo a los tokens de diseño:

```javascript
// tailwind.config.js
module.exports = {
  presets: [
    require('maguitoui/preset')
  ],
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
    "./node_modules/maguitoui/**/*.{js,ts,tsx}",
  ],
}
```

### 2. Estilos Globales
Importa las variables de diseño en tu punto de entrada:

```javascript
import 'maguitoui/styles';
```

## Componentes Disponibles

### 🎯 Actions (Acciones)
```tsx
import { Button, FAB, Swap, Dropdown, DropdownItem } from 'maguitoui';
```

### 📍 Navigation (Navegación)
```tsx
import { Navbar, Dock, DockItem, Breadcrumbs, Pagination, Tabs, Steps, Link } from 'maguitoui';
```

### 📦 Cards & Layout
```tsx
import { Card, Fieldset, Filter, Drawer, Stack, Indicator, Artboard } from 'maguitoui';
```

### 📝 Inputs (Formularios)
```tsx
import { Input, Textarea, Checkbox, Radio, Toggle, Select, Slider, Rating, FileInput, Label, Validator, Join, Kbd } from 'maguitoui';
```

### 💬 Feedback
```tsx
import { Spinner, LoadingDots, Progress, RadialProgress, Skeleton, Toast, Tooltip, Alert, Badge, Status } from 'maguitoui';
```

### 🎨 Content Display
```tsx
import { Avatar, Divider, Stat, Table, TableHead, TableBody, TableRow, TableHeader, TableCell, Timeline, List, ChatBubble, Carousel, Hero, Mask, Diff, Hover3DCard } from 'maguitoui';
```

### 🔧 Interactive
```tsx
import { Accordion, Modal, Calendar, Countdown, ThemeController } from 'maguitoui';
```

### Utilities
```tsx
import { cn } from 'maguitoui'; // utility functions
```

## Ejemplo Rápido

```tsx
import { Button, Card, Input, Badge } from 'maguitoui';
import 'maguitoui/styles';

function MiComponente() {
  return (
    <Card className="p-6">
      <Badge variant="primary">Nuevo</Badge>
      <h2 className="text-2xl font-bold">Hola MaguitoUI</h2>
      <Input label="Email" placeholder="tu@email.com" />
      <Button variant="primary" className="mt-4">Enviar</Button>
    </Card>
  );
}
```

## Temas Personalizados

MaguitoUI incluye un sistema de temas con variables CSS. Puedes personalizar:

- Colores (primary, secondary, accent, etc.)
- Bordes (radius, stroke weight)
- Sombras (depth)
- Fuentes (body, display)

```tsx
import { ThemeController } from 'maguitoui';

const temas = [
  { name: 'Naranja', colors: { primary: '#F18652', secondary: '#79BCE8' } },
  { name: 'Rosa', colors: { primary: '#FF2D95', secondary: '#22D3EE' } },
];

<ThemeController themes={temas} activeTheme={0} onThemeChange={setTheme} />
```

Diseñado con 💜 y magia por **Maguito Studio**.
